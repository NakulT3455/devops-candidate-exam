
import requests
import os
import json
import boto3
import base64


def lambda_handler(event, context):


  
  request_body = {
        "name": "Nakul Thorat",
        "subnet": os.environ['subnetId'],
        "emailID": "thoratnakul@gmail.com"
        
    }
 
  request_headers = {
        "Content-Type": "application/json",
        "X-Siemens-Auth": "test"
    }

  url = "https://ij92qpvpma.execute-api.eu-west-1.amazonaws.com/candidate-email_serverless_lambda_stage/data"
  json_payload=json.dumps(request_body)
  response = requests.post(url, headers=request_headers, data=json_payload)

  
  print(response)


